interface ISampleWidgetSettings {
  pipelineId: number;
  blink: boolean;
}
